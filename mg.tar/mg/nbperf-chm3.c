/*	$NetBSD: nbperf-chm3.c,v 1.1 2009/08/15 16:21:05 joerg Exp $	*/

#define BUILD_CHM3
#include "nbperf-chm.c"
