/*
 * DragonFly BSD-specific support.
 */

#include <sys/param.h>
#include <time.h>

/* Defines */
#define MAXNAMLEN 255
